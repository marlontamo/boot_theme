# atom Wordpress Theme

Exclusively used by Custom A Design and Linkage UIX Design Team

## Installation Instructions

This theme requires that you have GIT, NodeJS, Bower and GulpJS installed

Clone theme repository in wordpress theme folder

    git clone git@github.com:atom-uix/atom-wp-theme.git

Run bower

    bower install

Run node install

    npm install

Put your Virtual Host on gulpfile.js line #16

	var virtualHost = '// PUT YOUR VIRTUAL HOST HERE //'; 

Run gulp

    gulp


author: marcel badua